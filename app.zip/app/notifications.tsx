// app/notifications.tsx
import NotificationCenter from '@/components/NotificationCenter';

export default function NotificationsScreen() {
  return <NotificationCenter />;
}

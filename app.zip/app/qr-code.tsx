// app/qr-code.tsx
import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { db } from '@/config/firebase';
import { Colors } from '@/constants/Colors';
import { useAuth } from '@/contexts/AuthContext';
import { Ionicons } from '@expo/vector-icons';
import { notifyConnectionRequest } from '@/utils/notifications';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { router, useLocalSearchParams } from 'expo-router';
import {
  addDoc,
  arrayUnion,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  increment,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where
} from 'firebase/firestore';
import { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  Keyboard,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import QRCode from 'react-native-qrcode-svg';

type UserProfile = {
  firstName: string;
  lastInitial: string;
  displayName: string;
  airline: string;
  base: string;
  photoURL?: string;
};

type Plan = {
  id: string;
  title: string;
  hostUserId: string;
  hostName: string;
  spotName: string;
  city: string;
  attendeeIds: string[];
};

export default function QRCodeModal() {
  const { user } = useAuth();
  const { tab: initialTab } = useLocalSearchParams<{ tab?: string }>();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'show' | 'scan' | 'search'>(
    initialTab === 'scan' ? 'scan' : initialTab === 'search' ? 'search' : 'show'
  );
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const [processing, setProcessing] = useState(false);
  
  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<(UserProfile & { id: string })[]>([]);
  const [searching, setSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [connectingTo, setConnectingTo] = useState<string | null>(null);
  const searchTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  
  // DEBOUNCE FIX: Use ref to track last scan time
  const lastScanRef = useRef<number>(0);
  const SCAN_COOLDOWN = 3000; // 3 seconds between scans

  useEffect(() => {
    const loadProfile = async () => {
      if (!user) return;
      
      try {
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        if (userDoc.exists()) {
          setProfile(userDoc.data() as UserProfile);
        }
      } catch (error) {
        console.error('Error loading profile:', error);
      } finally {
        setLoading(false);
      }
    };

    loadProfile();
  }, [user]);

  const handleShare = async () => {
    try {
      const connectLink = `https://crewmateapp.dev/connect/${user?.uid}`;
      await Share.share({
        message: `Connect with me on CrewMate! ✈️\n\n${connectLink}`,
        title: 'Connect on CrewMate',
      });
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };

  // Share referral link to invite new crew to the app
  const handleShareReferral = async () => {
    try {
      const referralLink = `https://crewmateapp.dev/refer/${user?.uid}`;
      await Share.share({
        message: `Hey crew! I'm on CrewMate — the app built by and for airline crew. Join using my link and we can connect during layovers:\n\n${referralLink}`,
        title: 'Join CrewMate',
      });
    } catch (error) {
      console.error('Error sharing referral:', error);
    }
  };

  // Check if users are connected
  const checkConnection = async (userId1: string, userId2: string): Promise<boolean> => {
    const connectionsQuery = query(
      collection(db, 'connections'),
      where('userIds', 'array-contains', userId1)
    );
    const snapshot = await getDocs(connectionsQuery);
    return snapshot.docs.some(doc => doc.data().userIds.includes(userId2));
  };

  // Handle plan QR code scan
  const handlePlanQRCode = async (planId: string) => {
    if (!user || !profile) return;

    try {
      // Get plan details
      const planDoc = await getDoc(doc(db, 'plans', planId));
      if (!planDoc.exists()) {
        Alert.alert('Error', 'Plan not found. It may have been cancelled.');
        resetScanner();
        return;
      }

      const plan = { id: planDoc.id, ...planDoc.data() } as Plan;

      // Check if already attending
      if (plan.attendeeIds?.includes(user.uid)) {
        Alert.alert(
          'Already Joined!',
          `You're already part of "${plan.title}"`,
          [
            {
              text: 'View Plan',
              onPress: () => {
                resetScanner();
                router.back();
                router.push({ pathname: '/plan/[id]', params: { id: planId } });
              }
            },
            {
              text: 'OK',
              onPress: () => resetScanner()
            }
          ]
        );
        return;
      }

      // Check if connected to host
      const isConnectedToHost = await checkConnection(user.uid, plan.hostUserId);

      if (isConnectedToHost) {
        // Connected - just join the plan
        await joinPlan(planId, plan.title);
        resetScanner();
      } else {
        // Not connected - ask to connect first
        Alert.alert(
          'Join Plan',
          `"${plan.title}" is hosted by ${plan.hostName}. You're not connected yet. Would you like to send a connection request and join the plan?`,
          [
            {
              text: 'Cancel',
              style: 'cancel',
              onPress: () => resetScanner()
            },
            {
              text: 'Connect & Join',
              onPress: async () => {
                // Send connection request to host
                await sendConnectionRequest(plan.hostUserId, plan.hostName, planId);
                // Join the plan
                await joinPlan(planId, plan.title);
                resetScanner();
              }
            }
          ]
        );
      }
    } catch (error) {
      console.error('Error handling plan QR:', error);
      Alert.alert('Error', 'Failed to join plan. Please try again.');
      resetScanner();
    }
  };

  // Send connection request
  const sendConnectionRequest = async (toUserId: string, toUserName: string, pendingPlanId?: string) => {
    if (!user || !profile) return;

    // Check if request already exists
    const existingQuery = query(
      collection(db, 'connectionRequests'),
      where('fromUserId', '==', user.uid),
      where('toUserId', '==', toUserId),
      where('status', '==', 'pending')
    );
    const existingSnapshot = await getDocs(existingQuery);
    
    if (existingSnapshot.empty) {
      await addDoc(collection(db, 'connectionRequests'), {
        fromUserId: user.uid,
        fromUserName: profile.displayName,
        toUserId: toUserId,
        toUserName: toUserName,
        status: 'pending',
        createdAt: serverTimestamp(),
        ...(pendingPlanId && { pendingPlanInvite: pendingPlanId }),
      });
    }
  };

  // Join a plan
  const joinPlan = async (planId: string, planTitle: string) => {
    if (!user || !profile) return;

    try {
      // Add user to plan
      await updateDoc(doc(db, 'plans', planId), {
        attendeeIds: arrayUnion(user.uid),
        attendeeCount: increment(1),
        updatedAt: serverTimestamp(),
      });

      // Add attendee document
      await setDoc(doc(db, 'plans', planId, 'attendees', user.uid), {
        userId: user.uid,
        displayName: profile.displayName,
        photoURL: profile.photoURL || null,
        rsvpStatus: 'going',
        joinedAt: serverTimestamp(),
        joinedViaQR: true,
      });

      Alert.alert(
        'Joined! 🎉',
        `You've joined "${planTitle}"!`,
        [
          {
            text: 'View Plan',
            onPress: () => {
              router.back();
              router.push({ pathname: '/plan/[id]', params: { id: planId } });
            }
          },
          { text: 'OK' }
        ]
      );
    } catch (error) {
      console.error('Error joining plan:', error);
      throw error;
    }
  };

  // Handle user QR code scan — INSTANT CONNECT
  // QR scanning is mutual consent (you showed your code, they scanned it)
  // so we skip the request/approve flow and connect immediately
  const handleUserQRCode = async (scannedUserId: string) => {
    if (!user || !profile) return;

    // Check if scanning yourself
    if (scannedUserId === user.uid) {
      Alert.alert('Oops!', "You can't connect with yourself! 😄", [
        { text: 'OK', onPress: () => resetScanner() }
      ]);
      return;
    }

    // Get scanned user's profile
    const scannedUserDoc = await getDoc(doc(db, 'users', scannedUserId));
    if (!scannedUserDoc.exists()) {
      Alert.alert('Error', 'User not found. They may have deleted their account.', [
        { text: 'OK', onPress: () => resetScanner() }
      ]);
      return;
    }

    const scannedUserData = scannedUserDoc.data() as UserProfile;

    // Check if already connected
    const isConnected = await checkConnection(user.uid, scannedUserId);

    if (isConnected) {
      Alert.alert(
        'Already Connected! ✈️',
        `You and ${scannedUserData.displayName} are already crew! Check Messages to chat.`,
        [
          {
            text: 'Message',
            onPress: () => {
              resetScanner();
              router.back();
              router.push('/(tabs)/messages');
            }
          },
          { text: 'OK', onPress: () => resetScanner() }
        ]
      );
      return;
    }

    // Clean up any pending requests in either direction
    const cleanupRequests = async () => {
      try {
        // Requests I sent to them
        const myRequestsQuery = query(
          collection(db, 'connectionRequests'),
          where('fromUserId', '==', user.uid),
          where('toUserId', '==', scannedUserId),
          where('status', '==', 'pending')
        );
        const myRequests = await getDocs(myRequestsQuery);
        for (const reqDoc of myRequests.docs) {
          await deleteDoc(doc(db, 'connectionRequests', reqDoc.id));
        }

        // Requests they sent to me
        const theirRequestsQuery = query(
          collection(db, 'connectionRequests'),
          where('fromUserId', '==', scannedUserId),
          where('toUserId', '==', user.uid),
          where('status', '==', 'pending')
        );
        const theirRequests = await getDocs(theirRequestsQuery);
        for (const reqDoc of theirRequests.docs) {
          await deleteDoc(doc(db, 'connectionRequests', reqDoc.id));
        }
      } catch (err) {
        console.warn('Error cleaning up pending requests:', err);
      }
    };

    // Create the connection directly — QR scan = mutual consent
    try {
      await cleanupRequests();

      await addDoc(collection(db, 'connections'), {
        userIds: [user.uid, scannedUserId],
        userNames: {
          [user.uid]: profile.displayName,
          [scannedUserId]: scannedUserData.displayName,
        },
        createdAt: serverTimestamp(),
        connectedViaQR: true,
      });

      // Notify them
      await notifyConnectionRequest(
        scannedUserId,
        user.uid,
        profile.displayName,
        profile.photoURL
      );

      Alert.alert(
        'Connected! ✈️',
        `You and ${scannedUserData.displayName} are now crew!`,
        [
          {
            text: 'Send a Message',
            onPress: () => {
              resetScanner();
              router.back();
              router.push('/(tabs)/messages');
            }
          },
          {
            text: 'Done',
            onPress: () => {
              resetScanner();
              router.back();
            }
          }
        ]
      );
    } catch (error) {
      console.error('Error creating instant connection:', error);
      Alert.alert('Error', 'Failed to connect. Please try again.', [
        { text: 'OK', onPress: () => resetScanner() }
      ]);
    }
  };

  // DEBOUNCE FIX: Reset scanner state
  const resetScanner = () => {
    setScanned(false);
    setProcessing(false);
  };

  // DEBOUNCE FIX: Enhanced handleBarCodeScanned with cooldown
  const handleBarCodeScanned = async ({ data }: { data: string }) => {
    const now = Date.now();
    
    // Check if we're in cooldown period
    if (now - lastScanRef.current < SCAN_COOLDOWN) {
      console.log('Scan ignored - cooldown active');
      return;
    }
    
    // Check if already processing
    if (scanned || processing) {
      console.log('Scan ignored - already processing');
      return;
    }
    
    // Update last scan time and set states
    lastScanRef.current = now;
    setScanned(true);
    setProcessing(true);

    try {
      // Check if it's a plan QR code (format: "PLAN:{planId}")
      if (data.startsWith('PLAN:')) {
        const planId = data.replace('PLAN:', '');
        await handlePlanQRCode(planId);
      } 
      // Check if it's a universal link (format: "https://crewmateapp.dev/connect/{userId}")
      else if (data.includes('crewmateapp.dev/connect/')) {
        const userId = data.split('/connect/')[1]?.split('?')[0];
        if (userId) await handleUserQRCode(userId);
      }
      // Check if it's a deep link (format: "crewmateapp://connect/{userId}")
      else if (data.startsWith('crewmateapp://connect/')) {
        const userId = data.replace('crewmateapp://connect/', '');
        await handleUserQRCode(userId);
      }
      // Fallback: treat as plain user ID (for backward compatibility with old QR codes)
      else {
        await handleUserQRCode(data);
      }
    } catch (error) {
      console.error('Error processing QR code:', error);
      Alert.alert('Error', 'Failed to process QR code. Please try again.', [
        { text: 'OK', onPress: () => resetScanner() }
      ]);
    }
  };

  // ─── SEARCH FUNCTIONS ────────────────────────────────────────────────
  const handleSearch = (text: string) => {
    setSearchQuery(text);
    
    // Clear previous timeout
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }

    if (text.trim().length < 2) {
      setSearchResults([]);
      setHasSearched(false);
      return;
    }

    // Debounce search by 400ms
    searchTimeoutRef.current = setTimeout(() => {
      performSearch(text.trim());
    }, 400);
  };

  const performSearch = async (searchText: string) => {
    if (!user) return;
    setSearching(true);
    setHasSearched(true);

    try {
      // Search by displayName — Firestore doesn't support full-text search,
      // so we fetch users and filter client-side. For alpha with <100 users this is fine.
      const usersSnap = await getDocs(collection(db, 'users'));
      const results: (UserProfile & { id: string })[] = [];
      const lowerSearch = searchText.toLowerCase();

      usersSnap.docs.forEach((userDoc) => {
        if (userDoc.id === user.uid) return; // Skip self

        const data = userDoc.data();
        const name = (data.displayName || '').toLowerCase();
        const firstName = (data.firstName || '').toLowerCase();
        const airline = (data.airline || '').toLowerCase();

        if (name.includes(lowerSearch) || firstName.includes(lowerSearch) || airline.includes(lowerSearch)) {
          results.push({
            id: userDoc.id,
            ...(data as UserProfile),
          });
        }
      });

      // Sort: exact name matches first, then alphabetical
      results.sort((a, b) => {
        const aName = (a.displayName || '').toLowerCase();
        const bName = (b.displayName || '').toLowerCase();
        const aStarts = aName.startsWith(lowerSearch) ? 0 : 1;
        const bStarts = bName.startsWith(lowerSearch) ? 0 : 1;
        if (aStarts !== bStarts) return aStarts - bStarts;
        return aName.localeCompare(bName);
      });

      setSearchResults(results);
    } catch (error) {
      console.error('Error searching users:', error);
      Alert.alert('Error', 'Failed to search. Please try again.');
    } finally {
      setSearching(false);
    }
  };

  const handleSendRequest = async (targetUserId: string, targetName: string) => {
    if (!user || !profile) return;
    setConnectingTo(targetUserId);

    try {
      // Check if already connected
      const isConnected = await checkConnection(user.uid, targetUserId);
      if (isConnected) {
        Alert.alert('Already Connected!', `You and ${targetName} are already crew!`);
        setConnectingTo(null);
        return;
      }

      // Check if request already exists in either direction
      const existingQuery = query(
        collection(db, 'connectionRequests'),
        where('fromUserId', '==', user.uid),
        where('toUserId', '==', targetUserId),
        where('status', '==', 'pending')
      );
      const existingSnap = await getDocs(existingQuery);
      if (!existingSnap.empty) {
        Alert.alert('Already Sent', `You already sent ${targetName} a connection request.`);
        setConnectingTo(null);
        return;
      }

      const reverseQuery = query(
        collection(db, 'connectionRequests'),
        where('fromUserId', '==', targetUserId),
        where('toUserId', '==', user.uid),
        where('status', '==', 'pending')
      );
      const reverseSnap = await getDocs(reverseQuery);
      if (!reverseSnap.empty) {
        Alert.alert('Check Connections', `${targetName} already sent you a request! Check your Connections to accept.`);
        setConnectingTo(null);
        return;
      }

      // Send request
      await addDoc(collection(db, 'connectionRequests'), {
        fromUserId: user.uid,
        fromUserName: profile.displayName,
        toUserId: targetUserId,
        toUserName: targetName,
        status: 'pending',
        createdAt: serverTimestamp(),
      });

      await notifyConnectionRequest(
        targetUserId,
        user.uid,
        profile.displayName,
        profile.photoURL
      );

      Alert.alert('Request Sent! ✈️', `Connection request sent to ${targetName}.`);
    } catch (error) {
      console.error('Error sending connection request:', error);
      Alert.alert('Error', 'Failed to send request. Please try again.');
    } finally {
      setConnectingTo(null);
    }
  };

  if (loading) {
    return (
      <ThemedView style={styles.container}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </ThemedView>
    );
  }

  if (!profile) {
    return (
      <ThemedView style={styles.container}>
        <ThemedText>Error loading profile</ThemedText>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeButton}>
          <ThemedText>Close</ThemedText>
        </TouchableOpacity>
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeButton}>
          <Ionicons name="close" size={28} color={Colors.text.primary} />
        </TouchableOpacity>
        <ThemedText style={styles.headerTitle}>Add Crew</ThemedText>
        <View style={{ width: 28 }} />
      </View>

      {/* Tab Selector */}
      <View style={styles.tabContainer}>
        <Pressable
          style={[styles.tab, tab === 'show' && styles.activeTab]}
          onPress={() => setTab('show')}
        >
          <ThemedText style={[styles.tabText, tab === 'show' && styles.activeTabText]}>
            My Code
          </ThemedText>
        </Pressable>
        <Pressable
          style={[styles.tab, tab === 'scan' && styles.activeTab]}
          onPress={() => {
            setTab('scan');
            resetScanner();
          }}
        >
          <ThemedText style={[styles.tabText, tab === 'scan' && styles.activeTabText]}>
            Scan
          </ThemedText>
        </Pressable>
        <Pressable
          style={[styles.tab, tab === 'search' && styles.activeTab]}
          onPress={() => setTab('search')}
        >
          <ThemedText style={[styles.tabText, tab === 'search' && styles.activeTabText]}>
            Search
          </ThemedText>
        </Pressable>
      </View>

      {/* Content */}
      {tab === 'show' ? (
        <View style={styles.qrContainer}>
          <View style={styles.qrWrapper}>
            <QRCode
              value={`https://crewmateapp.dev/connect/${user?.uid}`}
              size={250}
              backgroundColor="white"
              color={Colors.primary}
            />
          </View>
          
          <View style={styles.infoCard}>
            <ThemedText style={styles.infoTitle}>{profile.displayName}</ThemedText>
            <ThemedText style={styles.infoSubtitle}>
              {profile.airline} • {profile.base}
            </ThemedText>
          </View>

          {/* Share My Code — connect with existing crew */}
          <TouchableOpacity style={styles.shareButton} onPress={handleShare}>
            <Ionicons name="share-outline" size={20} color={Colors.white} />
            <ThemedText style={styles.shareButtonText}>Share My Link</ThemedText>
          </TouchableOpacity>

          <ThemedText style={styles.instructionText}>
            Have another crew member scan this code{'\n'}or share your link to connect instantly!
          </ThemedText>

          {/* Divider */}
          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <ThemedText style={styles.dividerText}>or</ThemedText>
            <View style={styles.dividerLine} />
          </View>

          {/* Invite Crew — referral flow for new users */}
          <TouchableOpacity style={styles.inviteButton} onPress={handleShareReferral}>
            <Ionicons name="person-add" size={20} color={Colors.primary} />
            <ThemedText style={styles.inviteButtonText}>Invite Crew to CrewMate</ThemedText>
          </TouchableOpacity>

          <ThemedText style={styles.inviteSubtext}>
            Earn badges when your crew joins!
          </ThemedText>

          {/* Link to full referral tracking screen */}
          <TouchableOpacity
            style={styles.trackingLink}
            onPress={() => {
              router.back();
              router.push('/referrals');
            }}
          >
            <ThemedText style={styles.trackingLinkText}>View Referral Progress →</ThemedText>
          </TouchableOpacity>
        </View>
      ) : tab === 'scan' ? (
        <View style={styles.scanContainer}>
          {permission?.granted ? (
            <>
              <CameraView
                style={styles.camera}
                facing="back"
                onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
                barcodeScannerSettings={{
                  barcodeTypes: ['qr'],
                }}
              />
              
              <View style={styles.scanOverlay}>
                <View style={styles.scanFrame} />
              </View>

              {scanned && (
                <View style={styles.scanningIndicator}>
                  <ActivityIndicator size="large" color={Colors.white} />
                  <ThemedText style={styles.scanningText}>Processing...</ThemedText>
                </View>
              )}

              <View style={styles.scanInstructions}>
                <ThemedText style={styles.scanInstructionText}>
                  Position QR code within the frame
                </ThemedText>
              </View>

              {scanned && (
                <TouchableOpacity
                  style={styles.resetButton}
                  onPress={resetScanner}
                >
                  <ThemedText style={styles.resetButtonText}>Scan Again</ThemedText>
                </TouchableOpacity>
              )}
            </>
          ) : (
            <View style={styles.permissionContainer}>
              <Ionicons name="camera-outline" size={64} color={Colors.text.secondary} />
              <ThemedText style={styles.permissionText}>
                Camera permission is required to scan QR codes
              </ThemedText>
              <TouchableOpacity style={styles.permissionButton} onPress={requestPermission}>
                <ThemedText style={styles.permissionButtonText}>Grant Permission</ThemedText>
              </TouchableOpacity>
            </View>
          )}
        </View>
      ) : (
        /* ─── SEARCH TAB ─────────────────────────────────────────────── */
        <View style={styles.searchContainer}>
          {/* Search Input */}
          <View style={styles.searchInputWrapper}>
            <Ionicons name="search" size={20} color={Colors.text.secondary} style={{ marginRight: 10 }} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search by name or airline..."
              placeholderTextColor={Colors.text.secondary}
              value={searchQuery}
              onChangeText={handleSearch}
              autoCapitalize="none"
              autoCorrect={false}
              returnKeyType="search"
            />
            {searchQuery.length > 0 && (
              <TouchableOpacity onPress={() => { setSearchQuery(''); setSearchResults([]); setHasSearched(false); }}>
                <Ionicons name="close-circle" size={20} color={Colors.text.secondary} />
              </TouchableOpacity>
            )}
          </View>

          {/* Results */}
          <ScrollView 
            style={styles.searchResults} 
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {searching ? (
              <View style={styles.searchStatus}>
                <ActivityIndicator size="small" color={Colors.primary} />
                <ThemedText style={styles.searchStatusText}>Searching...</ThemedText>
              </View>
            ) : !hasSearched ? (
              <View style={styles.searchStatus}>
                <Ionicons name="people-outline" size={48} color={Colors.text.disabled} />
                <ThemedText style={styles.searchStatusText}>
                  Search for crew by name or airline
                </ThemedText>
              </View>
            ) : searchResults.length === 0 ? (
              <View style={styles.searchStatus}>
                <Ionicons name="search-outline" size={48} color={Colors.text.disabled} />
                <ThemedText style={styles.searchStatusText}>
                  No crew found matching "{searchQuery}"
                </ThemedText>
                <ThemedText style={[styles.searchStatusText, { fontSize: 13, marginTop: 4 }]}>
                  They might not be on CrewMate yet — invite them!
                </ThemedText>
                <TouchableOpacity style={[styles.inviteButton, { marginTop: 16 }]} onPress={handleShareReferral}>
                  <Ionicons name="person-add" size={18} color={Colors.primary} />
                  <ThemedText style={styles.inviteButtonText}>Invite Crew</ThemedText>
                </TouchableOpacity>
              </View>
            ) : (
              <>
                <ThemedText style={styles.resultCount}>
                  {searchResults.length} crew member{searchResults.length !== 1 ? 's' : ''} found
                </ThemedText>
                {searchResults.map((result) => (
                  <TouchableOpacity
                    key={result.id}
                    style={styles.searchResultCard}
                    onPress={() => handleSendRequest(result.id, result.displayName)}
                    disabled={connectingTo === result.id}
                  >
                    <View style={styles.searchResultInfo}>
                      {result.photoURL ? (
                        <Image source={{ uri: result.photoURL }} style={styles.searchAvatar} />
                      ) : (
                        <View style={styles.searchAvatarFallback}>
                          <ThemedText style={styles.searchAvatarText}>
                            {result.firstName?.[0]}{result.lastInitial}
                          </ThemedText>
                        </View>
                      )}
                      <View style={styles.searchResultText}>
                        <ThemedText style={styles.searchResultName}>{result.displayName}</ThemedText>
                        <ThemedText style={styles.searchResultDetail}>
                          {[result.airline, result.position, result.base].filter(Boolean).join(' • ')}
                        </ThemedText>
                      </View>
                    </View>
                    {connectingTo === result.id ? (
                      <ActivityIndicator size="small" color={Colors.primary} />
                    ) : (
                      <View style={styles.connectButton}>
                        <Ionicons name="person-add-outline" size={16} color={Colors.white} />
                        <ThemedText style={styles.connectButtonText}>Connect</ThemedText>
                      </View>
                    )}
                  </TouchableOpacity>
                ))}
              </>
            )}
          </ScrollView>
        </View>
      )}
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  closeButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  tabContainer: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginBottom: 20,
    backgroundColor: Colors.border,
    borderRadius: 12,
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: Colors.white,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.text.secondary,
  },
  activeTabText: {
    color: Colors.primary,
    fontWeight: '600',
  },
  qrContainer: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  qrWrapper: {
    backgroundColor: Colors.white,
    padding: 30,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
    marginTop: 20,
  },
  infoCard: {
    alignItems: 'center',
    marginTop: 30,
  },
  infoTitle: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 4,
  },
  infoSubtitle: {
    fontSize: 16,
    color: Colors.text.secondary,
  },

  // ── Share My Code button ─────────────────────────────────────────────────
  shareButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: Colors.primary,
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 12,
    marginTop: 30,
  },
  shareButtonText: {
    color: Colors.White,
    fontSize: 16,
    fontWeight: '600',
  },
  instructionText: {
    fontSize: 14,
    color: Colors.text.secondary,
    textAlign: 'center',
    marginTop: 12,
    paddingHorizontal: 40,
  },

  // ── Divider ──────────────────────────────────────────────────────────────
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    marginTop: 28,
    marginBottom: 20,
    gap: 12,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: Colors.border,
  },
  dividerText: {
    fontSize: 13,
    color: Colors.text.secondary,
    fontWeight: '500',
  },

  // ── Invite Crew button ───────────────────────────────────────────────────
  inviteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: Colors.primary + '12',
    borderWidth: 1.5,
    borderColor: Colors.primary,
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 12,
  },
  inviteButtonText: {
    color: Colors.primary,
    fontSize: 16,
    fontWeight: '600',
  },
  inviteSubtext: {
    fontSize: 13,
    color: Colors.text.secondary,
    textAlign: 'center',
    marginTop: 8,
  },

  // ── Referral tracking link ───────────────────────────────────────────────
  trackingLink: {
    marginTop: 16,
    paddingVertical: 6,
  },
  trackingLinkText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: '600',
  },

  // ── Scan tab ─────────────────────────────────────────────────────────────
  scanContainer: {
    flex: 1,
    position: 'relative',
  },
  camera: {
    flex: 1,
  },
  scanOverlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scanFrame: {
    width: 250,
    height: 250,
    borderWidth: 3,
    borderColor: Colors.accent,
    borderRadius: 20,
    backgroundColor: 'transparent',
  },
  scanningIndicator: {
    position: 'absolute',
    top: '50%',
    left: 0,
    right: 0,
    alignItems: 'center',
    marginTop: -50,
  },
  scanningText: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: '600',
    marginTop: 12,
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
  scanInstructions: {
    position: 'absolute',
    bottom: 100,
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  scanInstructionText: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: '500',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
  resetButton: {
    position: 'absolute',
    bottom: 40,
    alignSelf: 'center',
    backgroundColor: Colors.accent,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  resetButtonText: {
    color: Colors.primary,
    fontSize: 16,
    fontWeight: '600',
  },
  permissionContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
  },
  permissionText: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 30,
  },
  permissionButton: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 12,
  },
  permissionButtonText: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
  // ─── SEARCH TAB STYLES ──────────────────────────────────────────
  searchContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  searchInputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: Colors.text.primary,
    padding: 0,
  },
  searchResults: {
    flex: 1,
  },
  searchStatus: {
    alignItems: 'center',
    paddingTop: 60,
    paddingHorizontal: 20,
  },
  searchStatusText: {
    fontSize: 15,
    color: Colors.text.secondary,
    textAlign: 'center',
    marginTop: 12,
  },
  resultCount: {
    fontSize: 13,
    color: Colors.text.secondary,
    marginBottom: 12,
  },
  searchResultCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  searchResultInfo: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  searchAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
  },
  searchAvatarFallback: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchAvatarText: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
  searchResultText: {
    flex: 1,
    marginLeft: 12,
  },
  searchResultName: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text.primary,
  },
  searchResultDetail: {
    fontSize: 13,
    color: Colors.text.secondary,
    marginTop: 2,
  },
  connectButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 4,
    marginLeft: 8,
  },
  connectButtonText: {
    color: Colors.white,
    fontSize: 13,
    fontWeight: '600',
  },
});

// constants/theme.ts
// Re-export ThemeColors as Colors for theme system compatibility
export { ThemeColors as Colors } from './Colors';

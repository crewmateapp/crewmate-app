// hooks/useTheme.ts
// This file re-exports the useTheme hook from ThemeContext for backwards compatibility
export { useTheme } from '@/contexts/ThemeContext';

